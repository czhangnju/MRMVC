function idx = computeLabels(T, k)
    Z = (abs(T) + abs(T')) / 2;
    idx = clu_ncut(Z, k);
end