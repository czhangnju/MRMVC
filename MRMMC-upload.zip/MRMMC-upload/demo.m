clear 

addpath(genpath('./'))

load ORL.mat
%Y = gt;
cls_num = numel(unique(Y));

param.alpha = .01;
param.beta  = 10;

[G] = MRMMC(X, param);
for rp=1:5
    [Clus] = SpectralClustering(G, cls_num);
    [ACC,NMI,PUR] = ClusteringMeasure(Y,Clus); %ACC NMI Purity
    [Fscore,Precision,R] = compute_f(Y,Clus);
    [AR,~,~,~]=RandIndex(Y,Clus);
    result(rp,:) = [ACC NMI AR Fscore PUR Precision R];
end

mean_val = mean(result);
std_val  = std(result);
